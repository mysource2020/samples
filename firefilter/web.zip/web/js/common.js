 function del(id,url){
     if(confirm("ȷ��Ҫɾ����")){
        window.location.href=url;
     }
  }
 
 function delCon(id,url,content){
     if(confirm("ȷ��Ҫɾ��"+content+"��")){
        window.location.href=url;
     }
  }
  
  /*
  *  ȫѡ
  */
 function checkAll(id,allId){
    var check=document.getElementsByName(id);
    var checkboxAll=document.getElementById(allId);
    for(var i=0;i<check.length;i++){
      if(checkboxAll.checked){
      	check[i].checked=true;
      }else{
      	check[i].checked=false;
      }
       
    }
 }
  
  function deleteAll(ids,myForm,url){
     var check=document.getElementsByName(ids);
     var tag=true;
     var myForm=document.getElementById(myForm);//.forms[1];
     for(var i=0;i<check.length;i++){
       if(check[i].checked){
       	tag=false;
       }
     }
     if(tag){
        alert("��ѡ��Ҫɾ���ļ�¼��");
        return false;
     }
     
     if(confirm("ȷ��Ҫɾ����ѡ����¼��")){
        myForm.method="post";
        myForm.action=url;
        myForm.submit();
     }
  }
  
  function editorById(ids,url){
  	 var check=document.getElementsByName(ids);
     var seleceItems=0;
     var id;
     for(var i=0;i<check.length;i++){
       if(check[i].checked){
           seleceItems++;
           id=check[i].value;
       }
     }
     if(seleceItems==0){
       alert("��ѡ��Ҫ�޸ĵļ�¼");
       return false;
     }
     if(seleceItems>1){
       alert("ֻ��ѡ��һ����¼");
       return false;
     }
     window.location.href=url+id;
  }
  
  function editDateById(ids,url){
  	var check=document.getElementsByName(ids);
     var seleceItems=0;
     var id;
     for(var i=0;i<check.length;i++){
       if(check[i].checked){
           seleceItems++;
           id=check[i].value;
       }
     }
     if(seleceItems==0){
       alert("��ѡ��Ҫ�޸ĵļ�¼");
       return false;
     }
     window.location.href=url+id;
  }

function editorDateByTask(ids,myForm,url){
	var check=document.getElementsByName(ids);
	var myForm=document.getElementById(myForm);//.forms[1];
    var seleceItems=0;
    var id;
    for(var i=0;i<check.length;i++){
       if(check[i].checked){
           seleceItems++;
           id=check[i].value;
       }
     }
     if(seleceItems==0){
       alert("��ѡ��Ҫ�޸ĵļ�¼");
       return false;
     }
     myForm.method="post";
     myForm.action=url;
     myForm.submit();
}  
  
function trim(str){ 
	return str.replace(/(^\s*)|(\s*$)/g, ""); 
}
  
function checkIsInteger(str,name){ 
   if(trim(str) == ""){
      alert(name+"����Ϊ��");
   	  return false;
   }
   if(/^(\+|-)?\d+($|\.\d+$)/.test(str)){ 
     return true; 
   }else{
   	 alert(name+"ֻ��Ϊ����");
   	 return false;
   }	   
}

function checkIsInteger2(str,name) 
{ 
   if(str == "") 
       return true; 
   if(/^(\-?)(\d+)$/.test(str)){
     return true; 
   }else{
   	 alert(name+"ֻ��Ϊ����");
   	 return false;
   }	   
}